__version__ = "2.0.0"
__author__ = 'Julian Berrio, Megan Quinn, Navid Ali, Justin Miller, Michael Berry'
__credits__ = 'University of Florida'
